# coding: utf-8
"""Coordinate-derived set drawings. Proposed blocking dimensions, not measured architecture."""
from pathlib import Path
import json,math,zipfile,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent;ROOT=P.parent
FONT='/System/Library/Fonts/Hiragino Sans GB.ttc'
def font(n):return ImageFont.truetype(FONT,n)
BG='#f1efe7';INK='#223b32';MUT='#69776d';GOLD='#ad8150';GREEN='#718777';BLUE='#6c8895';WOOD='#b79a77';IVORY='#ddd8c7';DARK='#49524f'
models={};kits=[]
def model(k,bounds):models[k]={'id':k,'bounds':bounds,'objects':[],'openings':[],'rooms':[],'routes':[]};return models[k]
def box(m,i,name,x,z,w,d,h,c=WOOD,y=0,kind='furniture'):
 m['objects'].append(dict(id=i,name=name,x=x,z=z,w=w,d=d,h=h,y=y,color=c,kind=kind));return m['objects'][-1]
def wall(m,i,x,z,w,d,h=2.8):return box(m,i,'固定墙体',x,z,w,d,h,IVORY,kind='wall')
def opening(m,i,name,x,z,x2,z2,kind='door',sill=0,height=2.15):
 m['openings'].append(dict(id=i,name=name,a=[x,z],b=[x2,z2],kind=kind,sill=sill,height=height,hinge='a',swing='toward set center; proposed fixed hinge for review',base_elevation=0))
 # solid lower panel or glass shown with same placement in every view
 if kind=='window':box(m,i,name,min(x,x2),min(z,z2),max(.06,abs(x2-x)),max(.06,abs(z2-z)),height, '#9eb6bd',sill,'window')
 else:
  if abs(x2-x)>.1:
   wall(m,i+'-j1',min(x,x2)-.08,z,.08,.12,2.3);wall(m,i+'-j2',max(x,x2),z,.08,.12,2.3)
   box(m,i+'-lintel',name+'过梁',min(x,x2),z,abs(x2-x),.12,.22,IVORY,2.15,'wall')
  else:
   wall(m,i+'-j1',x,min(z,z2)-.08,.12,.08,2.3);wall(m,i+'-j2',x,max(z,z2),.12,.08,2.3)
   box(m,i+'-lintel',name+'过梁',x,min(z,z2),.12,abs(z2-z),.22,IVORY,2.15,'wall')
def table(m,i,name,x,z,w,d,h=.74):
 box(m,i,name,x,z,w,d,.1,WOOD,h-.1)
 for a,b in [(0,0),(w-.08,0),(0,d-.08),(w-.08,d-.08)]:box(m,i+'L',name+'桌腿',x+a,z+b,.08,.08,h-.1,WOOD)
def chair(m,i,x,z,c=WOOD):
 box(m,i,'椅面',x,z,.45,.45,.1,c,.42)
 box(m,i+'B','椅背',x,z,.45,.07,.45,c,.5)
 for a,b in [(0,0),(.38,0),(0,.38),(.38,.38)]:box(m,i+'L','椅腿',x+a,z+b,.07,.07,.42,c)
def sofa(m,x,z):
 box(m,'S1','蓝沙发坐垫',x,z,1.1,2,.28,BLUE,.33)
 box(m,'S1B','沙发靠背（东）',x+.86,z,.25,2,.72,BLUE,.25)
 for zz in [z,z+1.85]:box(m,'S1A','沙发扶手',x,zz,1.1,.15,.7,BLUE)
 for xx in [x+.1,x+.9]:
  for zz in [z+.1,z+1.8]:box(m,'S1L','沙发脚',xx,zz,.1,.1,.33,DARK)
def base(m,name='地坪',c='#cbb89e'):
 x,z,w,d=m['bounds'];box(m,'FLOOR',name,x,z,w,d,.12,c,-.12,'floor')
def room(m,name,b):m['rooms'].append(dict(name=name,bounds=b))
def kit(i,name,master,bounds,note,shots,focus=None):kits.append(dict(id=i,name=name,master=master,bounds=bounds,note=note,shots=shots,focus=focus or name))
# Apartment and communal corridor share a single frame. x east; z south; y up.
a=model('AP',[0,0,6.8,9.2]);base(a)
wall(a,'WN1',0,0,2.15,.12);wall(a,'WN2',4.35,0,2.45,.12);opening(a,'NW','北窗',2.15,0,4.35,0,'window',.85,1.5)
wall(a,'WW',0,0,.12,6.8);wall(a,'WE1',6.68,0,.12,1.45);wall(a,'WE2',6.68,3.15,.12,3.65)
opening(a,'PORTAL','异界门／非入户门',6.68,1.45,6.68,3.15,'portal')
wall(a,'WS1',0,6.68,1.45,.12);wall(a,'WS2',2.55,6.68,4.25,.12);opening(a,'ENTRY','公寓入户门',1.45,6.68,2.55,6.68)
wall(a,'BEDW',3.9,4,.12,2.68);wall(a,'BEDN',4.85,4,1.83,.12);opening(a,'BEDD','卧室门',4.02,4,4.85,4)
wall(a,'BATHN',4.02,5.6,2.66,.12);opening(a,'BATHD','浴室门（走廊侧）',3.9,5.78,3.9,6.5)
# split west bath wall to preserve doorway, not a door superimposed on solid wall
next(o for o in a['objects'] if o['id']=='BEDW')['d']=1.78
wall(a,'BWEND',3.9,6.5,.12,.18)
box(a,'K1','厨房工作台',.12,1.1,.72,2.0,.88,GREEN);box(a,'KTOP','厨房台面',.1,1.08,.77,2.04,.07,'#d4d1c3',.88)
box(a,'F1','冰箱',.18,.25,.7,.74,1.85,'#a1aaa5');box(a,'OVEN','炉灶',.16,1.3,.66,.65,.06,DARK,.95)
box(a,'SINK','水槽',.22,2.25,.45,.48,.03,'#899c9c',.955)
sofa(a,3.1,1.85);table(a,'T1','唯一客厅茶几',2.02,2,.7,1.65,.42);table(a,'D1','窗边餐桌',1.15,.4,.7,.65)
box(a,'R1','北窗暖气',2.15,.13,1.9,.18,.65,'#bfc3b9')
box(a,'TV1','固定电视柜',.2,3.45,.55,1.15,.7,WOOD);box(a,'TV2','电视',.16,3.48,.1,1.0,.7,DARK,.7)
box(a,'BED1','床架',4.8,4.6,1.5,.85,.32,WOOD);box(a,'BED2','床垫',4.8,4.6,1.5,.85,.22,'#c8b9ac',.32)
box(a,'BEDH','床头',6.3,4.6,.12,.85,.9,WOOD)
box(a,'NT1','床头柜',6.0,4.2,.4,.35,.55,WOOD)
box(a,'BASIN','盥洗台',4.2,6.05,.6,.4,.8,IVORY);box(a,'SHOWER','淋浴区',5.6,5.85,.8,.7,.07,'#a8babc');box(a,'WC','坐便器',5.0,6.1,.4,.45,.43,IVORY)
for j in range(3):box(a,'SC'+str(j+1),'不透明屏风第'+str(j+1)+'扇',5.5,2+j*.56,.1,.53,1.8,'#c4b594')
chair(a,'CH1',4.9,3.3);box(a,'H1','玄关边柜',.18,5.45,.55,1,.9,WOOD)
box(a,'TRAY','钥匙托盘',.23,5.65,.3,.3,.035,DARK,.9)
wall(a,'CORRIDORN',0,9.08,6.8,.12);wall(a,'CORRIDORW',0,6.8,.12,2.3);wall(a,'CORRIDORE',6.68,6.8,.12,2.3)
room(a,'客厅',[1.8,1.5,3.8,2.5]);room(a,'厨房',[0,.2,1,3]);room(a,'卧室',[4.02,4.12,2.66,1.48]);room(a,'浴室',[4.02,5.72,2.66,.96]);room(a,'公共楼道',[.12,6.8,6.56,2.28])
a['routes']=[[[4.45,5],[4.45,3.85],[4.5,1.5],[3.1,1.5]],[[2,7.5],[2,6.4],[1.5,4.6],[1.5,3.6]]]
# Exterior building/stair entrance. Topology only; floor count is not a story fact.
b=model('BL',[-1,-1,8,8]);base(b,'人行道','#c3c7bf');wall(b,'FACADE',0,1,6,.3,5.0)
for level in [2.8,4.1]:
 for xx in [.5,2.5,4.5]:box(b,'WIN','外立面窗',xx,.97,.8,.08,.9,'#8da8b4',level,'window')
# Replace middle ground facade with actual entry void
b['objects']=[o for o in b['objects'] if o['id']!='FACADE'];wall(b,'FAC1',0,1,2.2,.3,5);wall(b,'FAC2',3.4,1,2.6,.3,5);box(b,'FAC3','入口上墙',2.2,1,1.2,.3,2.8,IVORY,2.2,'wall')
opening(b,'MAIN','楼栋公共入口',2.2,1,3.4,1)
for j in range(5):box(b,'STEP'+str(j),'室外入口台阶',1.9,3.8-j*.45,1.8,.45,.18*(j+1),'#a1a59c')
box(b,'LAND','入口平台',1.9,1.3,1.8,.7,.9,'#a1a59c')
for xx in [1.82,3.75]:box(b,'RAIL','入口扶手',xx,1.4,.06,2.8,.06,DARK,1.8)
b['routes']=[[[2.8,5.5],[2.8,3.8],[2.8,1.5]]]
st=model('ST',[0,0,3.8,5.8]);base(st,'楼梯间地坪','#cccac0');wall(st,'STW',0,0,.12,5.8);wall(st,'STE',3.68,0,.12,5.8);wall(st,'STN',0,0,1.4,.12);wall(st,'STN2',2.4,0,1.4,.12);opening(st,'ROOFD','通天台门',1.4,0,2.4,0)
for j in range(10):box(st,'T'+str(j),'上行踏步',.45,4.8-j*.38,2.5,.38,.18*(j+1),'#b5b6ad')
box(st,'TOP','屋顶门前平台',.45,.2,2.5,1.15,1.8,'#b5b6ad');st['routes']=[[[1.8,5.5],[1.8,4.8],[1.8,1],[1.9,.2]]]
# Stair door is elevated with the landing; preserve standing head clearance.
for o in st['objects']:
 if o['kind']=='wall' and not o['id'].startswith('ROOFD'):o['h']=4.4
 if o['id'].startswith('ROOFD'):
  o['y']+=1.8
for q in st['openings']:q['base_elevation']=1.8
for o in b['objects']:
 if o['id'].startswith('MAIN'):o['y']+=.9
for q in b['openings']:q['base_elevation']=.9
# Clinic three connected zones; no new door/window switch between views.
c=model('CL',[0,0,8,9]);base(c,'诊所地坪','#d4d4ca')
for i,args in [('CW',(0,0,.12,9)),('CE',(7.88,0,.12,9)),('CN',(0,0,8,.12)),('CS1',(0,8.88,1,.12)),('CS2',(2.2,8.88,5.8,.12))]:wall(c,i,*args)
opening(c,'CENTRY','诊所南入口',1,8.88,2.2,8.88)
wall(c,'SUPN',0,3.5,2.6,.12);wall(c,'SUPN2',3.6,3.5,4.4,.12);opening(c,'SUPD','储物间门',2.6,3.5,3.6,3.5)
wall(c,'YARDN',0,1.6,2.6,.12);wall(c,'YARDN2',3.6,1.6,4.4,.12);opening(c,'YARDD','后院独立出口',2.6,1.6,3.6,1.6)
box(c,'CTR','固定接待台',4.2,5.5,2.7,.7,1.05,GREEN);box(c,'CTRT','接待台面',4.16,5.46,2.78,.78,.07,WOOD,1.05)
box(c,'MON','前台显示器',5.7,5.62,.48,.12,.35,DARK,1.12)
for xx in [.35,5.8]:box(c,'SHELF','储物架',xx,2,.6,1.2,2,'#849286')
box(c,'CARRIER','猫包固定操作位',4.55,5.55,.7,.45,.45,'#5b7880',1.12)
box(c,'BOWL','门后金属碗位',3.9,3.08,.22,.22,.1,'#a5b1ad');box(c,'BENCH','候诊长椅',.4,6.2,.6,1.8,.55,BLUE)
for xx in [.5,6.3]:box(c,'PLANT','后院花池',xx,.3,1,.6,.55,GREEN)
room(c,'候诊 / 接待',[.12,3.62,7.76,5.26]);room(c,'储物间',[.12,1.72,7.76,1.78]);room(c,'后院',[.12,.12,7.76,1.48]);c['routes']=[[[1.6,8.5],[2.5,6.6],[3.7,5.8]],[[3.1,4],[3.1,3.1],[3.1,1.1]]]
# Shelter yard + street are contiguous, with fenced kennel, overhead awning and practical gate.
s=model('SH',[0,0,8,8]);base(s,'收容所与街巷地坪','#b9c0b7');wall(s,'BRICK',0,0,8,.2,3)
box(s,'AWNING','避雨棚',.6,.2,3.3,2.5,.12,DARK,2.7,'roof')
for xx in [.65,3.8]:box(s,'POST','雨棚立柱',xx,2.5,.09,.09,2.7,DARK)
# wire fences built as posts/bars, not opaque walls
for xx in [1,2.7]:
 for zz in [.4,2.2]:box(s,'KP','笼体立柱',xx,zz,.06,.06,1.5,DARK)
for zz in [.4,2.2]:
 for xx in np.arange(1,2.71,.17):box(s,'KW','笼网竖丝',float(xx),zz,.015,.02,1.5,'#6b7a76')
 for yy in np.arange(.15,1.51,.2):box(s,'KH','笼网横丝',1,zz,1.76,.02,.015,'#6b7a76',float(yy))
for xx in [1,2.7]:
 for zz in np.arange(.4,2.21,.17):box(s,'KS','笼侧网竖丝',xx,float(zz),.02,.015,1.5,'#6b7a76')
 for yy in np.arange(.15,1.51,.2):box(s,'KSH','笼侧网横丝',xx,.4,.02,1.86,.015,'#6b7a76',float(yy))
box(s,'KENNEL','笼内软垫',1.1,.6,1.5,1.4,.05,'#c6bda8');box(s,'KBOWL','笼内水碗',2.2,1.7,.25,.25,.12,'#9cacaa')
opening(s,'YARDG','院门通街道',4.4,4.8,5.6,4.8)
for xx,w in [(0,4.4),(5.6,2.4)]:
 box(s,'FY','院界矮墙',xx,4.8,w,.12,.8,'#8f9c90')
box(s,'CURB','街道边石',0,6.4,8,.15,.16,'#abb0a6');box(s,'STREET','湿街道',0,6.55,8,1.45,.04,'#89938d');s['routes']=[[[1.8,3],[3.5,3.5],[5,4.8],[5,6.1]]]
# Roof and utility enclosure.
r=model('RF',[0,0,8,6]);base(r,'天台铺装','#b1b7af')
for i,args in [('RN',(0,0,8,.12)),('RW',(0,0,.12,6)),('RS',(0,5.88,8,.12)),('RE',(7.88,0,.12,6))]:box(r,i,'固定护栏基座',*args,.5,'#87978d')
box(r,'BENCH','长椅坐面',2.4,2.5,2,.55,.11,WOOD,.43);box(r,'BENCHB','长椅靠背（南）',2.4,3.0,2,.1,.48,WOOD,.52)
for xx in [2.5,4.1]:box(r,'BLEG','长椅脚',xx,2.55,.13,.4,.43,DARK)
wall(r,'UTILN',5.2,3.4,2.1,.15);wall(r,'UTILE',7.15,3.4,.15,2.3);wall(r,'UTILW',5.2,3.4,.15,2.3)
wall(r,'UTILS1',5.2,5.55,.3,.15);wall(r,'UTILS2',6.6,5.55,.7,.15);opening(r,'UD','楼梯机房门',5.5,5.55,6.6,5.55)
for xx in [.5,6.7]:box(r,'POT','固定花池',xx,.6,.65,.7,.5,GREEN)
r['routes']=[[[6,5.5],[4.8,4.5],[4.6,2.3],[3.3,2.3]]]
# Portal/court as connected boundary volumes; court depth is proposed, not story fact.
g=model('GT',[-2.5,0,6.5,8]);base(g,'两世界门槛','#bfc6c0')
box(g,'APT','公寓侧木地板',-2.5,0,2.5,8,.02,'#c2a985')
box(g,'COURT','王庭侧黑石地坪',0,0,4,8,.02,'#59626a')
wall(g,'PORTW1',-.08,0,.16,3,2.8);wall(g,'PORTW2',-.08,5,.16,3,2.8);opening(g,'GATE','东墙异界门',0,3,0,5,'portal',0,2.6)
for xx in [1,3.4]:
 for zz in [1,3,5,7]:box(g,'PILLAR','王庭固定柱列',xx,zz,.25,.25,3.4,'#778080')
box(g,'REAR','王庭后墙',3.9,0,.1,8,3.4,'#677279',kind='wall')
g['routes']=[[[ -1.6,4],[-.5,4],[.3,4],[2,4]]]
# Actual shot associations; extra rooms are revealed only as connected set details.
story=json.loads((ROOT/'season-20260929/storyboard.json').read_text());allshots=[q for e in story['episodes'] for q in e['shots']]
def ids(sc):return [q['id'] for q in allshots if q['scene'] in sc]
kit('A00','公寓总平面与连接','AP',[0,0,6.8,9.2],'原户型拓扑为基准；家具细分、浴室门与楼道深度为本轮布景提案。',ids(['apartment','kitchen','entry','bedroom','steps','gate']))
kit('A01','客厅 · 沙发与屏风','AP',[1.7,.0,4.98,4.0],'沙发朝西；茶几在西侧；屏风在东侧。近景不改变家具位置。',ids(['apartment']))
kit('A02','厨房与窗边餐区','AP',[0,0,2.05,3.45],'厨房台面与窗边餐桌是两件不同的固定物件，不能替代客厅茶几。',ids(['kitchen']))
kit('A03','公寓玄关与门槛','AP',[0,4.2,3.9,3.4],'门外为封闭楼道；门槛和玄关边柜跨镜固定。',ids(['entry','steps']))
kit('A04','卧室','AP',[3.9,4,2.78,1.6],'床、床头柜与门洞为固定体积；具体紧凑尺寸待确认。',ids(['bedroom']))
kit('A05','浴室与浴室门口','AP',[3.9,5.6,2.78,1.08],'剧情明确出现浴室门口；内部洁具为补全提案，不增加新剧情。',['E02-08','E02-B02','E02-15'])
kit('B01','公共楼道与室内等候平台','AP',[0,6.68,6.8,2.52],'此处不是室外露台；与南入户门共用同一门洞。',ids(['steps','entry']))
kit('B02','楼梯间与上行平台','ST',[0,0,3.8,5.8],'上行连接天台；台阶数量、坡高与扶手细节为比例预演，非施工尺寸。',ids(['stairs']))
kit('B03','公寓楼外立面与外台阶','BL',[-1,-1,8,8],'依据外景参考；立面层数仅作可见背景体量，不设定整栋楼真实层数。',['E01-B01','E03-B04'])
kit('C01','诊所前台与候诊区','CL',[0,3.5,8,5.5],'诊所入口在南，储物间在前台后方；通路不穿过柜台。',['E02-01','E02-03','E02-04','E02-05','E02-06','E02-07A','E02-B01A'])
kit('C02','诊所储物间','CL',[0,1.6,8,2.02],'架、门、猫碗的位置固定；后院出口与前台门不同。',['E02-02','E02-06','E02-07A','E02-07B'])
kit('C03','诊所后院','CL',[0,0,8,1.72],'猫经后门到后院；不能把后门替换为低窗跳跃。',['E02-07B','E02-B01B'])
kit('S01','收容所雨棚与猫舍','SH',[0,0,8,5.05],'June在笼外、猫在笼内；笼门与院门不同。笼网在模型中有实际体积。',ids(['shelter']))
kit('S02','收容所出口与街道','SH',[0,3.3,8,4.7],'与收容所同一模型；院门跨出后才进入街道。',ids(['street','apartment→shelter']))
kit('R01','天台长椅与机房入口','RF',[0,0,8,6],'长椅朝北护栏；机房门在南东侧。天际线属于远景方位，不能通过移动门补构图。',ids(['roof','roof→apartment']))
kit('G01','异界门与双世界门槛','GT',[-2.5,1.8,5,4.4],'这是公寓东墙上的界面，与南入户门完全不同；两侧地面不能混同。',ids(['gate']))
kit('G02','王庭门厅与柱廊','GT',[0,0,4,8],'仅建剧情可见的门厅与柱廊；后方尺度为提案，不虚构完整宫殿。',ids(['gate']))
# Geometry utilities; every view and OBJ uses the same cuboid vertices.
FACES=[(0,1,2,3),(4,7,6,5),(0,4,5,1),(3,2,6,7),(0,3,7,4),(1,5,6,2)]
def vertices(o):
 x,z,w,d,y,h=o['x'],o['z'],o['w'],o['d'],o['y'],o['h']
 return np.array([[x,y,z],[x+w,y,z],[x+w,y,z+d],[x,y,z+d],[x,y+h,z],[x+w,y+h,z],[x+w,y+h,z+d],[x,y+h,z+d]])
def subset(m,b):
 x,z,w,d=b
 return [o for o in m['objects'] if o['kind']!='floor' and o['x']<x+w and o['x']+o['w']>x and o['z']<z+d and o['z']+o['d']>z]
def colors(c,f):
 rgb=tuple(int(c[i:i+2],16)for i in [1,3,5]);return tuple(min(255,int(v*f))for v in rgb)
def panel_header(im,title,sub):
 dr=ImageDraw.Draw(im);dr.text((65,35),'ONE NIGHT, NINE LIVES  /  SET ATLAS 09.30',font=font(19),fill=MUT);dr.text((65,70),title,font=font(40),fill=INK);dr.text((65,130),sub,font=font(21),fill=MUT)
def footer(im,kit):
 dr=ImageDraw.Draw(im);dr.line((65,im.height-65,im.width-65,im.height-65),fill='#c8cec3',width=2);dr.text((65,im.height-49),'同源几何 · x=东 / z=南 / y=上 · u=布景相对单位，非实测米 · 尺寸为待确认提案',font=font(18),fill=MUT)
def fit_text(dr,xy,txt,limit=70,size=20,fill=MUT):
 words=[txt[i:i+limit] for i in range(0,len(txt),limit)]
 for i,t in enumerate(words):dr.text((xy[0],xy[1]+i*(size+9)),t,font=font(size),fill=fill)
def render3d(im,rect,objs,b,az=135,el=35,persp=False,title=''):
 dr=ImageDraw.Draw(im);rx,ry,rw,rh=rect;dr.rounded_rectangle((rx,ry,rx+rw,ry+rh),20,fill='#e4e7dc')
 x,z,w,d=b;target=np.array([x+w/2,.7,z+d/2]);az=math.radians(az);el=math.radians(el)
 direction=np.array([math.cos(el)*math.cos(az),math.sin(el),math.cos(el)*math.sin(az)])
 dist=max(w,d)*1.45+2;eye=target+direction*dist;forward=-direction;right=np.cross(forward,np.array([0,1,0]));right/=np.linalg.norm(right);up=np.cross(right,forward)
 faces=[];points=[]
 floor=dict(x=x,z=z,w=w,d=d,y=-.1,h=.1,color='#cbb99e',kind='floor',id='GROUND')
 for o in [floor]+objs:
  # Interior views are documented cutaways; wall at 0.4u prevents hiding the set behind a facade.
  oo=dict(o)
  if oo['kind']=='wall':oo['h']=min(oo['h'],.45);oo['y']=0
  if oo['kind']=='roof':continue
  vv=vertices(oo);rel=vv-eye
  v=np.stack([rel@right,rel@up,rel@forward],axis=1)
  for idx,face in enumerate(FACES):
   facev=v[list(face)];depth=facev[:,2].mean()
   if persp:
    if np.min(facev[:,2])<=.1:continue
    xy=facev[:,:2]/facev[:,2:3]*dist
   else:xy=facev[:,:2]
   points.extend(xy.tolist());faces.append((depth+(100000 if oo['kind']=='floor' else 0),xy,colors(oo['color'],[.77,1,.86,.92,.80,.9][idx])))
 if not points:return
 pts=np.array(points);lo=pts.min(axis=0);hi=pts.max(axis=0);span=np.maximum(hi-lo,.1);scale=min((rw-75)/span[0],(rh-105)/span[1]);center=(lo+hi)/2
 def screen(q):return (rx+rw/2+(q[0]-center[0])*scale,ry+rh/2+22-(q[1]-center[1])*scale)
 for dep,xy,c in sorted(faces,key=lambda a:a[0],reverse=True):dr.polygon([screen(q)for q in xy],fill=c,outline='#7d8a7d',width=1)
 dr.text((rx+22,ry+15),title,font=font(23),fill=INK)
 dr.text((rx+22,ry+rh-33),'剖切显示：墙体降至 0.45u，顶棚隐藏；并非改变实际模型',font=font(15),fill=MUT)
def plan(im,rect,objs,m,b):
 dr=ImageDraw.Draw(im);rx,ry,rw,rh=rect;x,z,w,d=b;scale=min((rw-120)/w,(rh-150)/d);ox=rx+(rw-w*scale)/2;oz=ry+(rh-d*scale)/2
 def xy(xx,zz):return(ox+(xx-x)*scale,oz+(zz-z)*scale)
 dr.rectangle((ox,oz,ox+w*scale,oz+d*scale),fill='#e8e6d9',outline=INK,width=3)
 for o in sorted(objs,key=lambda a:a['y']):
  if o['kind']=='roof':continue
  x1=max(x,o['x']);z1=max(z,o['z']);x2=min(x+w,o['x']+o['w']);z2=min(z+d,o['z']+o['d'])
  if x2<=x1 or z2<=z1:continue
  dr.rectangle((*xy(x1,z1),*xy(x2,z2)),fill=o['color'],outline='#7c887c',width=1)
  if o['w']*o['d']>.22 and o['id']not in ['BED2','APT','COURT'] and o['y']<1:dr.text(xy(x1+.03,z1+.03),o['id'],font=font(17),fill=INK)
 for q in m['openings']:
  a1,a2=q['a'],q['b']
  if not (x-.2<=a1[0]<=x+w+.2 and z-.2<=a1[1]<=z+d+.2):continue
  aa,bb=xy(*a1),xy(*a2);col='#5f8c99'if q['kind']=='window'else '#ae7e55';dr.line((*aa,*bb),fill=col,width=6)
  dr.text((aa[0]+5,aa[1]-25),q['id'],font=font(17),fill=col)
  if q['kind']=='door':
   length=math.dist(a1,a2);cx,cz=m['bounds'][0]+m['bounds'][2]/2,m['bounds'][1]+m['bounds'][3]/2
   if abs(a2[0]-a1[0])>.1:leaf=[a1[0],a1[1]+(length if cz>a1[1] else -length)]
   else:leaf=[a1[0]+(length if cx>a1[0] else -length),a1[1]]
   dr.line((*aa,*xy(*leaf)),fill=col,width=2)
   v0=np.array(a2)-np.array(a1);v1=np.array(leaf)-np.array(a1);arc=[]
   for tt in np.linspace(0,math.pi/2,20):arc.append(xy(*(np.array(a1)+v0*math.cos(tt)+v1*math.sin(tt))))
   dr.line(arc,fill=col,width=1)
 for path in m['routes']:
  vv=[xy(*v) for v in path if x<=v[0]<=x+w and z<=v[1]<=z+d]
  if len(vv)>1:dr.line(vv,fill=GOLD,width=4);dr.ellipse((vv[-1][0]-6,vv[-1][1]-6,vv[-1][0]+6,vv[-1][1]+6),fill=GOLD)
 # dimensions and north marker
 dr.text((ox+w*scale/2-35,oz-43),f'{w:g} u',font=font(21),fill=INK);dr.text((ox-64,oz+d*scale/2),f'{d:g} u',font=font(21),fill=INK)
 dr.text((rx+15,ry+15),'N 北 ↑',font=font(23),fill=INK)
 dr.text((rx+15,ry+rh-28),'金线＝动作路线　蓝线＝窗　棕线＝门洞　灰块＝固定墙体',font=font(17),fill=MUT)
def elevation(im,rect,objs,b,axis,reverse,title,openings):
 dr=ImageDraw.Draw(im);rx,ry,rw,rh=rect;dr.rounded_rectangle((rx,ry,rx+rw,ry+rh),16,fill='#e4e7dc');x,z,w,d=b
 low=x if axis=='x' else z;span=w if axis=='x' else d;H=max(3,max(o['y']+o['h'] for o in objs));sc=min((rw-85)/span,(rh-90)/H);left=rx+(rw-span*sc)/2;bottom=ry+rh-36
 # Full wall heights remain outlined in architectural views, even though 3D sheets cut them away.
 for tick in np.arange(0,H+.01,.5):
  yy=bottom-tick*sc;dr.line((left-8,yy,left+span*sc,yy),fill='#d2d8cc',width=1);dr.text((left-52,yy-9),f'{tick:g}',font=font(14),fill=MUT)
 for o in objs:
  if o['kind']!='wall':continue
  aa=o[axis];ll=o['w'if axis=='x'else'd'];aa1=max(low,aa);aa2=min(low+span,aa+ll)
  if aa2<=aa1:continue
  if reverse:aa1,aa2=low+span-(aa2-low),low+span-(aa1-low)
  dr.rectangle((left+(aa1-low)*sc,bottom-(o['y']+o['h'])*sc,left+(aa2-low)*sc,bottom-o['y']*sc),outline='#aab8a9',width=1)
 for o in sorted(objs,key=lambda o:o['z'] if axis=='x'else o['x'],reverse=not reverse):
  if o['kind']in ['wall','roof']:continue
  a=o[axis];length=o['w'if axis=='x'else'd'];a1=max(low,a);a2=min(low+span,a+length)
  if a2<=a1:continue
  if reverse:a1,a2=low+span-(a2-low),low+span-(a1-low)
  dr.rectangle((left+(a1-low)*sc,bottom-(o['y']+o['h'])*sc,left+(a2-low)*sc,bottom-o['y']*sc),fill=o['color'],outline='#718171',width=1)
 for q in openings:
  index=0 if axis=='x' else 1;aa1=max(low,min(q['a'][index],q['b'][index]));aa2=min(low+span,max(q['a'][index],q['b'][index]))
  if aa2-aa1<.1:continue
  if not (b[0]-.2<=q['a'][0]<=b[0]+b[2]+.2 and b[1]-.2<=q['a'][1]<=b[1]+b[3]+.2):continue
  if reverse:aa1,aa2=low+span-(aa2-low),low+span-(aa1-low)
  yy=q.get('base_elevation',0)+q.get('sill',0);color='#658c9a'if q['kind']=='window'else GOLD
  dr.rectangle((left+(aa1-low)*sc,bottom-(yy+q['height'])*sc,left+(aa2-low)*sc,bottom-yy*sc),outline=color,width=3)
  dr.text((left+(aa1-low)*sc,bottom-(yy+q['height'])*sc-20),q['id'],font=font(14),fill=color)
 dr.line((left,bottom,left+span*sc,bottom),fill=INK,width=2);dr.text((rx+18,ry+14),title,font=font(22),fill=INK);dr.text((rx+18,ry+rh-26),'正投影；墙体线框，门窗与陈设共用高度基准 u',font=font(15),fill=MUT)
def obj_export(path,objs):
 lines=['# Proposed set geometry; unit u, not surveyed metres','mtllib geometry.mtl'];mat=[];offset=0
 for j,o in enumerate(objs):
  lines+=['o '+o['id']+'_'+str(j),'usemtl m'+str(j)]
  mat+=['newmtl m'+str(j),'Kd '+' '.join(str(round(int(o['color'][i:i+2],16)/255,5))for i in [1,3,5]),'']
  for v in vertices(o):lines.append('v '+' '.join(f'{a:.5f}'for a in v))
  for f in FACES:lines.append('f '+' '.join(str(offset+n+1)for n in f))
  offset+=8
 path.write_text('\n'.join(lines));path.with_name('geometry.mtl').write_text('\n'.join(mat))
(P/'models').mkdir(exist_ok=True)
for k,m in models.items():(P/'models'/f'{k}.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
for k in kits:
 dest=P/k['id'];dest.mkdir(exist_ok=True);m=models[k['master']];objs=subset(m,k['bounds']);b=k['bounds']
 for kind,title in [('3d','三维体块与空间关系'),('plan','户型 / 场地平面'),('architecture','建筑展开与高度关系'),('angles','四向空间视图')]:
  im=Image.new('RGB',(2200,1600),BG);panel_header(im,k['id']+' '+k['name']+' · '+title,'同一个模型导出所有视图；陈设不随镜头变化。尺寸为待确认的布景比例。')
  if kind=='3d':
   render3d(im,(60,195,1510,1250),objs,b,135,32,False,'轴测剖切 / AXONOMETRIC')
   fit_text(ImageDraw.Draw(im),(1630,240),k['note'],18,22)
   yy=460;seen=set()
   for o in objs:
    if o['kind'] in ['wall','floor']or o['name']in seen or yy>1360:continue
    seen.add(o['name']);ImageDraw.Draw(im).text((1630,yy),o['id']+' '+o['name'],font=font(19),fill=INK);yy+=36
  elif kind=='plan':
   plan(im,(60,195,1510,1230),objs,m,b);fit_text(ImageDraw.Draw(im),(1640,230),k['note'],18,22)
   yy=440
   for q in m['openings']:
    if b[0]-.2<=q['a'][0]<=b[0]+b[2]+.2 and b[1]-.2<=q['a'][1]<=b[1]+b[3]+.2:
     fit_text(ImageDraw.Draw(im),(1625,yy),q['id']+' '+q['name'],19,20);yy+=95
  elif kind=='architecture':
   for rect,ax,rev,t in [((60,200,1020,590),'x',False,'北向展开'),((1120,200,1020,590),'x',True,'南向展开'),((60,825,1020,590),'z',False,'东向展开'),((1120,825,1020,590),'z',True,'西向展开')]:elevation(im,rect,objs,b,ax,rev,t,m['openings'])
  else:
   for rect,az,t in [((60,200,1020,590),135,'V1 从西南看东北'),((1120,200,1020,590),45,'V2 从东南看西北'),((60,825,1020,590),225,'V3 从西北看东南'),((1120,825,1020,590),315,'V4 从东北看西南')]:render3d(im,rect,objs,b,az,22,True,t)
  footer(im,k);im.save(dest/(kind+'.png'),optimize=True)
 obj_export(dest/'geometry.obj',[dict(id='GROUND',x=b[0],z=b[1],w=b[2],d=b[3],y=-.12,h=.12,color='#cbb99e')]+objs)
 k['files']={name:f"{k['id']}/{name}.png"for name in ['3d','plan','architecture','angles']};k['model_file']=k['id']+'/geometry.obj';k['objects']=len(objs)
 print('RENDERED',k['id'],k['name'],flush=True)
manifest={'version':'scene-atlas-0930','status':'coordinate-derived_set_design_proposal_not_video_acceptance','units':'u relative blocking units, not measured metres','kits':kits,'masters':list(models),'images':len(kits)*4,'assumptions':['No complete building survey exists; heights, exact dimensions, unseen bathroom fixtures and court depth are proposals.','Existing apartment-plan.svg fixes topology; earlier generated beauty images may conflict and are not measurement evidence.','Cutaway 3D renders lower walls and hide roofs for legibility; complete wall geometry remains in OBJ.','Multi-angle views are geometry perspective projections, not AI-generated photorealistic final scene renders.','No character/video regeneration performed.'],'coverage':{q['id']:[k['id']for k in kits if q['id'] in k['shots']]for q in allshots}}
# Transitions cover both physical endpoints, not fictional third locations.
for q in allshots:
 if q['scene']=='roof→apartment':manifest['coverage'][q['id']]=['R01','B02','A03','A01']
 if q['scene']=='apartment→shelter':manifest['coverage'][q['id']]=['A01','S02','S01']
manifest['unmapped']=[s for s,v in manifest['coverage'].items()if not v]
(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# Compact visual catalogue.
contact=Image.new('RGB',(2200,math.ceil(len(kits)/3)*430+170),BG);dd=ImageDraw.Draw(contact);dd.text((45,25),'全剧场景图集 / 17 套 · 68 张图 · 同源几何',font=font(36),fill=INK)
for n,k in enumerate(kits):
 im=Image.open(P/k['files']['3d']);im.thumbnail((690,360));x=40+(n%3)*720;y=115+(n//3)*430;contact.paste(im,(x,y));dd.text((x,y+355),k['id']+' '+k['name'],font=font(21),fill=INK)
contact.save(P/'contact-sheet.png',optimize=True)
print('IMAGES',manifest['images'],'UNMAPPED',manifest['unmapped'],flush=True)
